CONSTANT = "SUPER"

# from sub_package.myfile import BRO

# print(BRO)

