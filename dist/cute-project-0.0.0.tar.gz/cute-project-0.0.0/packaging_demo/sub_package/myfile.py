
## 
# from ..myotherfile import CONSTANT 
# from packaging.myotherfile import CONSTANT

# print(CONSTANT)

# import sys 
# sys.path.insert(0, "/workspaces/Learning_py_to_prod-pypi/packaging/")


# import sys 
# sys.path.insert(0, "/workspaces/Learning_py_to_prod-pypi")  ## This is the worst way to do that :( 


from packaging.myotherfile import CONSTANT
BRO = "LJLJ"
BRO = "NO BRO"
print(CONSTANT)