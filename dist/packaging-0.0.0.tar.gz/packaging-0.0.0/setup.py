from setuptools import setup 

setup(
    Name="my-cute-package", 
    version="0.0.0", 
    packages=['packaging'], 
    author="Aravind", 
    description="This is a cute project", 
    
)